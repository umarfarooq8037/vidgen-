import express from "express";
import ffmpeg from "fluent-ffmpeg";
import { EdgeTTS } from "node-edge-tts";
import { createClient } from "@supabase/supabase-js";
import fs from "fs"; import path from "path"; import os from "os";
import { Readable } from "stream"; import { pipeline } from "stream/promises";

const db = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });
const PEXELS = process.env.PEXELS_API_KEY;
const MUSIC = path.resolve("assets/music.mp3");
const SIZES = { "9:16": [1080, 1920], "16:9": [1920, 1080], "1:1": [1080, 1080] };
const ORIENT = { "9:16": "portrait", "16:9": "landscape", "1:1": "square" };
const MAX_SENTENCES = 14;

const STOP = {
  en: "a an the and or but if of to in on at by for with from is are was were be been this that these those it its i you he she we they my your his her our their as so not no do does did have has had will would can could just very".split(" "),
  ur: "اور کا کی کے کو سے میں پر ہے ہیں تھا تھی تھے ہو ہوں گا گی گے یہ وہ جو کہ بھی تو نے ایک کر کیا کیوں اس ان ہم آپ میرا آپ کی لیے ساتھ بہت".split(" "),
  hi: "और का की के को से में पर है हैं था थी थे हो हूँ गा गी गे यह वह जो कि भी तो ने एक कर क्या क्यों इस उन हम आप मेरा लिए साथ बहुत".split(" "),
};
const detect = (t) => (/[\u0900-\u097F]/.test(t) ? "hi" : /[\u0600-\u06FF]/.test(t) ? "ur" : "en");
const VOICES = { ur: ["ur-PK-AsadNeural", "ur-PK"], hi: ["hi-IN-MadhurNeural", "hi-IN"], en: ["en-US-AndrewNeural", "en-US"] };
const FONTS = { ur: "Noto Naskh Arabic", hi: "Noto Sans Devanagari", en: "Noto Sans" };

const splitSentences = (s) => s.split(/(?<=[.!?۔।؟])\s+|\n+/).map((x) => x.trim()).filter((x) => x.length > 1).slice(0, MAX_SENTENCES);
const keywordsOf = (words, lang) => words.filter((w) => !STOP[lang]?.includes(w.replace(/[^\p{L}]/gu, "")));

async function toEnglishQuery(sentence, lang) {
  try {
    let text = sentence;
    if (lang !== "en") {
      const r = await fetch("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=" + encodeURIComponent(sentence), { signal: AbortSignal.timeout(8000) });
      text = (await r.json())[0].map((x) => x[0]).join("");
    }
    const k = keywordsOf(text.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean), "en");
    return k.slice(0, 3).join(" ") || "cinematic nature";
  } catch { return "cinematic nature"; }
}

async function findClip(query, aspect, used) {
  const u = `https://api.pexels.com/videos/search?query=${encodeURIComponent(query)}&orientation=${ORIENT[aspect]}&per_page=8`;
  const r = await fetch(u, { headers: { Authorization: PEXELS } });
  if (!r.ok) return null;
  const vids = ((await r.json()).videos || []).filter((v) => !used.has(v.id));
  const v = vids[Math.floor(Math.random() * Math.min(vids.length, 4))];
  if (!v) return null;
  used.add(v.id);
  const files = v.video_files.filter((f) => f.file_type === "video/mp4" && f.width >= 720).sort((a, b) => a.width - b.width);
  return (files.find((f) => f.width >= 1080) || files.at(-1))?.link || null;
}
async function download(url, dest) {
  const r = await fetch(url); if (!r.ok) throw new Error("download failed");
  await pipeline(Readable.fromWeb(r.body), fs.createWriteStream(dest));
}
const probe = (f) => new Promise((res, rej) => ffmpeg.ffprobe(f, (e, d) => (e ? rej(e) : res(d.format.duration))));
const run = (cmd) => new Promise((res, rej) => cmd.on("end", res).on("error", (e, _o, se) => rej(new Error(e.message + " " + (se || "").slice(-300)))).run());

// ---- ASS captions: bold white, black stroke, yellow keyword, centered. libass shapes Urdu/Hindi correctly (drawtext does not). ----
const ts = (s) => { const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = (s % 60).toFixed(2).padStart(5, "0"); return `${h}:${String(m).padStart(2, "0")}:${x}`; };
function assHeader(W, H, font) {
  const size = Math.round(Math.min(W, H) * 0.075), mv = Math.round(H * (H > W ? 0.28 : 0.12));
  return `[Script Info]\nScriptType: v4.00+\nPlayResX: ${W}\nPlayResY: ${H}\nWrapStyle: 2\n\n[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\nStyle: Default,${font},${size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,${Math.round(size / 10)},0,2,60,60,${mv},1\n\n[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n`;
}
function captionEvents(sentence, start, dur, lang) {
  const words = sentence.split(/\s+/), chunks = [];
  for (let i = 0; i < words.length; i += 3) chunks.push(words.slice(i, i + 3));
  const total = chunks.reduce((a, c) => a + c.join(" ").length, 0); let t = start, out = "";
  for (const c of chunks) {
    const d = (dur * c.join(" ").length) / total;
    const key = [...keywordsOf(c, lang)].sort((a, b) => b.length - a.length)[0];
    const text = c.map((w) => (w === key ? `{\\c&H00FFFF&}${w}{\\c&HFFFFFF&}` : w)).join(" ");
    out += `Dialogue: 0,${ts(t)},${ts(t + d)},Default,,0,0,0,,${text}\n`; t += d;
  }
  return out;
}

async function render(job) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "job-"));
  const [W, H] = SIZES[job.aspect], lang = detect(job.script), [voice, vlang] = VOICES[lang];
  const sentences = splitSentences(job.script); if (!sentences.length) throw new Error("خالی سکرپٹ");
  const progress = (p) => db.from("jobs").update({ progress: Math.round(p) }).eq("id", job.id);
  const used = new Set(); let ass = assHeader(W, H, FONTS[lang]), clock = 0;
  const vlist = [], alist = [];

  try {
    for (let i = 0; i < sentences.length; i++) {
      const s = sentences[i], base = path.join(dir, `s${i}`);
      // 1) Edge TTS per sentence -> exact timing for captions + clips
      await new EdgeTTS({ voice, lang: vlang, outputFormat: "audio-24khz-96kbitrate-mono-mp3", timeout: 30000 }).ttsPromise(s, base + ".mp3");
      const dur = (await probe(base + ".mp3")) + 0.15;
      // 2) B-roll from Pexels
      let clip = null;
      try { const url = await findClip(await toEnglishQuery(s, lang), job.aspect, used); if (url) { clip = base + "_src.mp4"; await download(url, clip); } } catch { clip = null; }
      // 3) Segment: cover-crop to target, Ken Burns, color grade
      const vf = `scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=30,zoompan=z='min(zoom+0.0015,1.5)':d=1:s=${W}x${H}:fps=30,eq=saturation=1.2:contrast=1.1,setsar=1,format=yuv420p`;
      const cmd = ffmpeg();
      if (clip) cmd.input(clip).inputOptions(["-stream_loop -1"]);
      else cmd.input(`color=c=0x101830:s=${W}x${H}:r=30`).inputFormat("lavfi");
      cmd.outputOptions(["-t", String(dur), "-an", "-vf", vf, "-c:v libx264", "-preset veryfast", "-crf 23", "-r 30"]).save(base + ".mp4");
      await run(cmd);
      ass += captionEvents(s, clock, dur, lang); clock += dur;
      vlist.push(`file '${base}.mp4'`); alist.push(`file '${base}.mp3'`);
      await progress(5 + (80 * (i + 1)) / sentences.length);
    }
    fs.writeFileSync(path.join(dir, "v.txt"), vlist.join("\n")); fs.writeFileSync(path.join(dir, "a.txt"), alist.join("\n"));
    fs.writeFileSync(path.join(dir, "cap.ass"), ass);
    const video = path.join(dir, "video.mp4"), voiceF = path.join(dir, "voice.m4a"), out = path.join(dir, "final.mp4");
    await run(ffmpeg().input(path.join(dir, "v.txt")).inputOptions(["-f concat", "-safe 0"]).outputOptions(["-c copy"]).save(video));
    await run(ffmpeg().input(path.join(dir, "a.txt")).inputOptions(["-f concat", "-safe 0"]).outputOptions(["-c:a aac", "-ar 44100", "-ac 2"]).save(voiceF));
    await progress(90);

    // 4) Final mix: captions burned in + music auto-ducked under voice (sidechain compression)
    const hasMusic = fs.existsSync(MUSIC), cmd = ffmpeg().input(video).input(voiceF);
    const vfilter = `[0:v]ass=${path.join(dir, "cap.ass")}[v]`;
    let afilter;
    if (hasMusic) {
      cmd.input(MUSIC).inputOptions(["-stream_loop -1"]);
      afilter = "[1:a]asplit=2[sc][vo];[2:a]volume=0.30[m];[m][sc]sidechaincompress=threshold=0.02:ratio=20:attack=10:release=400[d];[vo][d]amix=inputs=2:duration=first:normalize=0[a]";
    } else afilter = "[1:a]anull[a]";
    cmd.complexFilter([vfilter, afilter], ["v", "a"])
      .outputOptions(["-c:v libx264", "-preset veryfast", "-crf 23", "-pix_fmt yuv420p", "-c:a aac", "-b:a 160k", "-shortest", "-movflags +faststart"]).save(out);
    await run(cmd); await progress(95);

    const key = `${job.id}.mp4`;
    const { error } = await db.storage.from("videos").upload(key, fs.readFileSync(out), { contentType: "video/mp4", upsert: true });
    if (error) throw new Error(error.message);
    const { data } = db.storage.from("videos").getPublicUrl(key);
    await db.from("jobs").update({ status: "done", progress: 100, video_url: data.publicUrl }).eq("id", job.id);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

// ---- Queue: poll DB, claim atomically, one render at a time (free-tier RAM) ----
let busy = false;
async function tick() {
  if (busy) return; busy = true;
  try {
    const { data: q } = await db.from("jobs").select("*").eq("status", "queued").order("created_at").limit(1);
    if (q?.length) {
      const { data: claimed } = await db.from("jobs").update({ status: "processing", progress: 2 }).eq("id", q[0].id).eq("status", "queued").select();
      if (claimed?.length) {
        try { await render(claimed[0]); }
        catch (e) { console.error(e); await db.from("jobs").update({ status: "failed", error: String(e.message).slice(0, 200) }).eq("id", q[0].id); }
      }
    }
  } finally { busy = false; }
}
setInterval(tick, 3000);
db.from("jobs").update({ status: "failed", error: "Server restarted" }).eq("status", "processing").then(() => {});

const app = express();
app.get("/wake", (_q, r) => { tick(); r.send("ok"); });
app.get("/", (_q, r) => r.send("worker up"));
app.listen(process.env.PORT || 10000);
