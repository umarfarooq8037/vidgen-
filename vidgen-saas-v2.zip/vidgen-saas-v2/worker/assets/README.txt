Put a royalty-free file named music.mp3 here (optional).
