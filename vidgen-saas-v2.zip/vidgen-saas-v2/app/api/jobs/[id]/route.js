import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(_req, { params }) {
  if (!/^[0-9a-f-]{36}$/.test(params.id)) return NextResponse.json({ error: "not found" }, { status: 404 });
  const { data: job } = await db().from("jobs").select("id,status,progress,video_url,error").eq("id", params.id).maybeSingle();
  if (!job) return NextResponse.json({ error: "not found" }, { status: 404 });
  if (!["done", "failed"].includes(job.status) && process.env.WORKER_URL)
    fetch(process.env.WORKER_URL + "/wake", { signal: AbortSignal.timeout(4000) }).catch(() => {});
  return NextResponse.json(job);
}
