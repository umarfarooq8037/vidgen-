-- Job queue (no users, no auth). Only server code (service role) can touch it.
create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  aspect text not null,
  script text not null,
  ip text,
  status text not null default 'queued',
  progress int default 0,
  video_url text,
  error text,
  created_at timestamptz default now()
);
alter table public.jobs enable row level security; -- no policies = browser cannot read/write directly
insert into storage.buckets (id, name, public) values ('videos','videos',true) on conflict do nothing;
