import { NextResponse } from "next/server";
import { db } from "@/lib/db";

const ASPECTS = ["9:16", "16:9", "1:1"];
export async function POST(req) {
  const { script, aspect } = await req.json();
  if (!ASPECTS.includes(aspect) || !script || script.trim().length < 10 || script.length > 2000)
    return NextResponse.json({ error: "سکرپٹ 10 سے 2000 حروف کے درمیان ہونی چاہیے" }, { status: 400 });
  const ip = (req.headers.get("x-forwarded-for") || "unknown").split(",")[0].trim();
  const d = db();
  // Abuse guard (no login = public link): one render at a time overall, max 10 videos/hour per visitor.
  const { count: active } = await d.from("jobs").select("id", { count: "exact", head: true })
    .in("status", ["queued", "processing"]).gte("created_at", new Date(Date.now() - 20 * 60000).toISOString());
  if (active > 0) return NextResponse.json({ error: "ایک ویڈیو ابھی بن رہی ہے، تھوڑی دیر بعد کوشش کریں" }, { status: 429 });
  const { count: hourly } = await d.from("jobs").select("id", { count: "exact", head: true })
    .eq("ip", ip).gte("created_at", new Date(Date.now() - 3600000).toISOString());
  if (hourly >= 10) return NextResponse.json({ error: "ایک گھنٹے کی حد پوری ہو گئی" }, { status: 429 });
  const { data: job, error } = await d.from("jobs").insert({ script: script.trim(), aspect, ip }).select("id").single();
  if (error) return NextResponse.json({ error: "job failed" }, { status: 500 });
  if (process.env.WORKER_URL) fetch(process.env.WORKER_URL + "/wake", { signal: AbortSignal.timeout(5000) }).catch(() => {});
  return NextResponse.json({ jobId: job.id });
}
